package com.example.shopping_online_prm392.common;

public class TableName {
    public static final String ACCOUNT_TABLE = "accounts";
    public static final String CATEGORY_TABLE = "category";
    public static final String PRODUCT_TABLE = "products";

    public  static final String CART_TABLE = "carts";
    public  static final String PAYMENT_TABLE = "payments";

}
