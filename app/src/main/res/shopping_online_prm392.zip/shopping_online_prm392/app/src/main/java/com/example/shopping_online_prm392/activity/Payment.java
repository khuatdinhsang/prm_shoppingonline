package com.example.shopping_online_prm392.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.shopping_online_prm392.R;

public class Payment extends AppCompatActivity {
    private void bindingView(){

    }

    private void bindingAction(){

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        bindingView();
        bindingAction();
    }
}
