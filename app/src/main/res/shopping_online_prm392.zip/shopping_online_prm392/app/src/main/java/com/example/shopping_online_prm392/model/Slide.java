package com.example.shopping_online_prm392.model;

public class Slide {
    private int slideId;

    public Slide(int slideId) {
        this.slideId = slideId;
    }

    public Slide() {
    }

    public int getSlideId() {
        return slideId;
    }

    public void setSlideId(int slideId) {
        this.slideId = slideId;
    }
}
